python3 detect.py --model_def config/yolov3-captcha.cfg --weights_path checkpoints/yolov3_ckpt.pth --image_folder data/captcha/test --class_path data/captcha/classes.names
