python3 train.py --model_def config/yolov3-captcha.cfg --data_config config/captcha.data --pretrained_weights weights/darknet53.conv.74
